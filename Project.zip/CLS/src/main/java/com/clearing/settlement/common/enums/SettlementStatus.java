package com.clearing.settlement.common.enums;

public enum SettlementStatus {
    PENDING, COMPLETED
}
