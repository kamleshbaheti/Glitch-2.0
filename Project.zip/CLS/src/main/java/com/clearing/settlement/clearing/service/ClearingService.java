package com.clearing.settlement.clearing.service;

import com.clearing.settlement.trade.model.Trade;

public class ClearingService {

    public void clearTrade(Trade trade) {
        double amount = trade.getExecutedQuantity() * trade.getExecutedPrice();

        System.out.println("Clearing Process:");
        System.out.println("Buyer pays ₹" + amount);
        System.out.println("Seller receives ₹" + amount);

        if (trade.getRefundAmount() > 0) {
            System.out.println("Refund to buyer: ₹" + trade.getRefundAmount());
        }
    }
}
