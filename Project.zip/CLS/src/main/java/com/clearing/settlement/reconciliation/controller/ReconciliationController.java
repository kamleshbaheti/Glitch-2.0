package com.clearing.settlement.reconciliation.controller;

import com.clearing.settlement.trade.model.Trade;
import com.clearing.settlement.reconciliation.service.ReconciliationService;

public class ReconciliationController {

    private final ReconciliationService service = new ReconciliationService();

    public void reconcile(Trade trade) {
        System.out.println(service.reconcile(trade));
    }
}
