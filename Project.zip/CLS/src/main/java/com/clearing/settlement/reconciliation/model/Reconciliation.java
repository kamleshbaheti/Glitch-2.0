package com.clearing.settlement.reconciliation.model;

import com.clearing.settlement.common.enums.ReconciliationStatus;

public class Reconciliation {
    private ReconciliationStatus status;

    public Reconciliation(ReconciliationStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Reconciliation Status: " + status;
    }
}
