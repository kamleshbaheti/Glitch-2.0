package com.clearing.settlement.trade.model;

import com.clearing.settlement.common.enums.OrderType;

public class Order {
    private int orderId;
    private int participantId;
    private String instrument;
    private int quantity;
    private double price;
    private OrderType type;

    public Order(int orderId, int participantId, String instrument,
                 int quantity, double price, OrderType type) {
        this.setOrderId(orderId);
        this.participantId = participantId;
        this.instrument = instrument;
        this.quantity = quantity;
        this.price = price;
        this.type = type;
    }
    public int getParticipantId() { return participantId; }
    public String getInstrument() { return instrument; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public OrderType getType() { return type; }
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
}
