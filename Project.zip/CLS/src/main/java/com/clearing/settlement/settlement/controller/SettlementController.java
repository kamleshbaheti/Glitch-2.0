package com.clearing.settlement.settlement.controller;

import com.clearing.settlement.settlement.model.Settlement;
import com.clearing.settlement.settlement.service.SettlementService;

public class SettlementController {

    private final SettlementService settlementService = new SettlementService();

    public Settlement executeSettlement() {
        Settlement settlement = new Settlement();
        settlementService.settle(settlement);
        return settlement;
    }
}
