package com.clearing.settlement.clearing.model;

public class Clearing {
    private int participantId;
    private double amount;

    public Clearing(int participantId, double amount) {
        this.participantId = participantId;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Participant " + participantId + " obligation: ₹" + amount;
    }
}
