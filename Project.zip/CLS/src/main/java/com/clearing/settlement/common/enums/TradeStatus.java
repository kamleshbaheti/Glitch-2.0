package com.clearing.settlement.common.enums;

public enum TradeStatus {
    MATCHED, PARTIALLY_MATCHED, UNMATCHED
}
