package com.clearing.settlement.app;

import com.clearing.settlement.trade.model.*;
import com.clearing.settlement.common.enums.OrderType;
import com.clearing.settlement.trade.controller.*;
import com.clearing.settlement.clearing.controller.*;
import com.clearing.settlement.settlement.controller.*;
import com.clearing.settlement.reconciliation.controller.*;

public class ApplicationRunner {

    public static void main(String[] args) {

        System.out.println("=== CLEARING & SETTLEMENT SYSTEM ===");

        Order buyOrder = new Order(1, 101, "INFY", 80, 1520, OrderType.BUY);
        Order sellOrder = new Order(2, 201, "INFY", 100, 1500, OrderType.SELL);
        
        

        TradeController tradeController = new TradeController();
        ClearingController clearingController = new ClearingController();
        SettlementController settlementController = new SettlementController();
        ReconciliationController reconciliationController = new ReconciliationController();

        Trade trade = tradeController.processTrade(buyOrder, sellOrder);

        if (trade != null) {
            clearingController.processClearing(trade);
            settlementController.executeSettlement();
            reconciliationController.reconcile(trade);
        }

        System.out.println("=== PROCESS COMPLETED ===");
    }
}
