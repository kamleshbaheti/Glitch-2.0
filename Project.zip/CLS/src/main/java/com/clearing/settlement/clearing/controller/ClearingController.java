package com.clearing.settlement.clearing.controller;

import com.clearing.settlement.trade.model.Trade;
import com.clearing.settlement.clearing.service.ClearingService;

public class ClearingController {

    private final ClearingService clearingService = new ClearingService();

    public void processClearing(Trade trade) {
        clearingService.clearTrade(trade);
    }
}
