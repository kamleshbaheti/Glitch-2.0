package com.clearing.settlement.common.enums;

public enum OrderType {
	BUY, SELL
}
