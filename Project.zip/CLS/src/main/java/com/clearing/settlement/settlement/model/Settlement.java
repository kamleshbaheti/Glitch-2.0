package com.clearing.settlement.settlement.model;

import com.clearing.settlement.common.enums.SettlementStatus;

public class Settlement {
    private SettlementStatus status = SettlementStatus.PENDING;

    public void complete() {
        status = SettlementStatus.COMPLETED;
    }

    public SettlementStatus getStatus() {
        return status;
    }
}
