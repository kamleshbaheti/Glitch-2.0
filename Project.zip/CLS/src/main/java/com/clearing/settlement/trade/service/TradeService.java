package com.clearing.settlement.trade.service;

import com.clearing.settlement.trade.model.*;
import com.clearing.settlement.common.enums.*;

public class TradeService {

    public Trade matchOrders(Order buy, Order sell) {

        if (!buy.getInstrument().equals(sell.getInstrument())) {
            return null;
        }

        if (buy.getPrice() < sell.getPrice()) {
            return null;
        }

        int executedQty = Math.min(buy.getQuantity(), sell.getQuantity());
        double executionPrice = sell.getPrice();

        TradeStatus status;
        if (buy.getQuantity() == sell.getQuantity()) {
            status = TradeStatus.MATCHED;
        } else {
            status = TradeStatus.PARTIALLY_MATCHED;
        }

        double buyerCommitment = buy.getQuantity() * buy.getPrice();
        double actualCost = executedQty * executionPrice;
        double refund = buyerCommitment - actualCost;

        return new Trade(
                1,
                buy,
                sell,
                executedQty,
                executionPrice,
                status,
                refund
        );
    }
}
