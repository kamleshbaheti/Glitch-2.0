package com.clearing.settlement.reconciliation.service;

import com.clearing.settlement.trade.model.Trade;
import com.clearing.settlement.common.enums.ReconciliationStatus;
import com.clearing.settlement.reconciliation.model.Reconciliation;

public class ReconciliationService {

    public Reconciliation reconcile(Trade trade) {

        boolean fundsOk = true;
        boolean securitiesOk = trade.getExecutedQuantity() > 0;

        if (fundsOk && securitiesOk) {
            return new Reconciliation(ReconciliationStatus.MATCHED);
        }
        return new Reconciliation(ReconciliationStatus.DISCREPANCY);
    }
}
