package com.clearing.settlement.trade.model;

import com.clearing.settlement.common.enums.TradeStatus;

public class Trade {
    private int tradeId;
    private Order buyOrder;
    private Order sellOrder;
    private int executedQuantity;
    private double executedPrice;
    private TradeStatus status;
    private double refundAmount;

    public Trade(int tradeId, Order buyOrder, Order sellOrder,
                 int executedQuantity, double executedPrice,
                 TradeStatus status, double refundAmount) {
        this.setTradeId(tradeId);
        this.buyOrder = buyOrder;
        this.sellOrder = sellOrder;
        this.executedQuantity = executedQuantity;
        this.executedPrice = executedPrice;
        this.status = status;
        this.refundAmount = refundAmount;
    }

    public Order getBuyOrder() { return buyOrder; }
    public Order getSellOrder() { return sellOrder; }
    public int getExecutedQuantity() { return executedQuantity; }
    public double getExecutedPrice() { return executedPrice; }
    public TradeStatus getStatus() { return status; }
    public double getRefundAmount() { return refundAmount; }

	public int getTradeId() {
		return tradeId;
	}

	public void setTradeId(int tradeId) {
		this.tradeId = tradeId;
	}
}