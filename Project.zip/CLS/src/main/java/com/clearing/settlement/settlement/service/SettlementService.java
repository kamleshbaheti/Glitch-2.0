package com.clearing.settlement.settlement.service;

import com.clearing.settlement.settlement.model.Settlement;

public class SettlementService {

    public void settle(Settlement settlement) {
        System.out.println("Settlement in progress...");
        settlement.complete();
        System.out.println("Settlement Status: " + settlement.getStatus());
    }
}
