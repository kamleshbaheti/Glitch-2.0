package com.clearing.settlement.trade.controller;

import com.clearing.settlement.trade.model.*;
import com.clearing.settlement.trade.service.TradeService;

public class TradeController {

    private final TradeService tradeService = new TradeService();

    public Trade processTrade(Order buy, Order sell) {
        System.out.println("Matching buy & sell orders...");
        Trade trade = tradeService.matchOrders(buy, sell);

        if (trade == null) {
            System.out.println("No trade matched.");
            return null;
        }

        System.out.println("Trade Status: " + trade.getStatus());
        return trade;
    }
}
